<!-- Footer -->
<footer class="footer pt-0">

</footer>
</div>
</div>
<!-- Argon Scripts -->
<!-- Core -->
<script src="<?= base_url('assets/template/') ?>vendor/jquery/dist/jquery.min.js"></script>
<script src="<?= base_url('assets/template/') ?>vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/template/') ?>vendor/js-cookie/js.cookie.js"></script>
<script src="<?= base_url('assets/template/') ?>vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
<script src="<?= base_url('assets/template/') ?>vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
<!-- Argon JS -->
<script src="<?= base_url('assets/template/') ?>js/argon.js?v=1.2.0"></script>

</body>

</html>